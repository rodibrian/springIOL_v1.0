create function get_article_unite_quantite_peremption(magasinid bigint, articleid bigint, uniteid bigint)
    returns TABLE(date_peremption date, quantite_peremption double precision)
    language plpgsql
as
$$
begin
return query select ap.date_peremption,sum(ap.quantite_peremption) from approv ap join info_article_magasin iam on iam.id = ap.info_article_magasin_id
where iam.magasin_id =magasinId and iam.unite_id=uniteId and iam.article_id = articleId and ap.quantite_peremption > 0 group by ap.date_peremption order by date_peremption;
end
$$;

alter function get_article_unite_quantite_peremption(bigint, bigint, bigint) owner to postgres;

