create procedure mettre_a_jour_date_peremption(IN id_magasin bigint, IN id_article bigint, IN id_unite bigint, IN new_date timestamp without time zone, IN old_date timestamp without time zone)
    language plpgsql
as
$$
DECLARE
    row RECORD;
BEGIN

    for row in select ap1.id from approv ap1 join info_article_magasin iam on iam.id = ap1.info_article_magasin_id where iam.magasin_id=id_magasin and iam.article_id= id_article and iam.unite_id = id_unite and ap1.date_peremption =old_date
    loop
            update approv set  date_peremption =  new_date where id = row.id;
    end loop;

END;
$$;

alter procedure mettre_a_jour_date_peremption(bigint, bigint, bigint, timestamp, timestamp) owner to postgres;

