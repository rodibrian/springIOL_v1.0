create function fn_change_time_punch_audit() returns trigger
    language plpgsql
as
$$
begin
    insert into unite (categorie)
    values
    	('test');
    return new;
  end;
$$;

alter function fn_change_time_punch_audit() owner to postgres;

