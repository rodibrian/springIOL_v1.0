create function updatestock() returns trigger
    language plpgsql
as
$$
begin
	
	if new.magasin_id = old.magasin_id 
	   AND new.unite_id = old.unite_id 
	   AND new.article_id = old.article_id
	   AND new.date_peremption = old.date_peremption THEN

	   UPDATE info_article_magasin SET quantite_stock = ( SELECT old.quantite_stock + new.quantite_stock)  
		   WHERE (magasin_id = old.magasin_id AND unite_id = old.unite_id AND article_id = old.article_id);
	end if;	   
    return new;
	
end;
$$;

alter function updatestock() owner to postgres;

